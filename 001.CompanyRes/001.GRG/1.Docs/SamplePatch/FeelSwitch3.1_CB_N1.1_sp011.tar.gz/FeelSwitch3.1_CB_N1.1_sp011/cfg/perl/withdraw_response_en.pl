#! /usr/bin/perl -w
sub proc {
	my $f22;
	my $f24;
	my $f31;
	my $f32;
	my $f33;
	my $f57;
	my $f59;
	my $f61;
	  ($f22,$f24,$f31,$f32,$f33,$f57,$f59,$f61) = @_;
	 
	  my $nextStateNum = "000";
	  my $nextScreenNum = "000";
	  my $nextScreenNumExt = "000";
	  my $cardflag= "0";
	  my $journaldata;	
	  my $receiptdata;
	  my $priceipt;
	  my $CardNumber = substr($f22,0,6)."******".substr($f22,12,4);
	  
	  $f24 =~ s/^0*//;
	  $f24 /= 100;
	  print "the value is $f59 \n";
	  if ($f59 eq "00") {
		$nextStateNum = "512";
		$nextScreenNum = "505";
		$cardflag= "0";
		$nextScreenNumExt ="007@@       RETIRO DE CHEQUES        C@426DFG@436"; 
		
		$journaldata = sprintf("%s\n#ATM:%s\nDate:%s  Time:%s\nPan:%s\nTraceNo:%s  TransType:%s\n\
RespCode:00\nSearchIndex:%s\n", "Withdraw", $f61, $f33, $f32, $f22, $f31, "Withdraw",$f57);
		
		open(my $FILEP, "../cfg/ndccfg/cent_data/prtformat/EN/102.txt") || die "open file error, $! ";
		while(defined($priceipt = <$FILEP>))
		{
			$receiptdata .= $priceipt;
		}
		close($FILEP);
		$receiptdata=~ s/#1/$f33/;	
		$receiptdata=~ s/#2/$f32/;	
		$receiptdata=~ s/#3/$f61/;	
		$receiptdata=~ s/#4/$CardNumber/;	
		$receiptdata=~ s/#9/$f31/;	
		$receiptdata=~ s/#6/$f24/;	
	  }
	  else
	  {
		$nextStateNum = "559";
	  }	 	  
	  if($f59 ne "00")
	  {
	  	$journaldata = sprintf("%s\n#ATM:%s\nDate:%s  Time:%s\nPan:%s\nTraceNo:%s  TransType:%s\n\
ErrorCode:%s\nSearchIndex:%s\n", "Withdraw", $f61, $f33, $f32, $f22, $f31, "Withdraw",$f59,$f57);
	  }
	  print "the perl value is $nextStateNum \n";
	  return ($nextStateNum, $nextScreenNum, $nextScreenNumExt,$journaldata, $receiptdata,$cardflag);
	}

