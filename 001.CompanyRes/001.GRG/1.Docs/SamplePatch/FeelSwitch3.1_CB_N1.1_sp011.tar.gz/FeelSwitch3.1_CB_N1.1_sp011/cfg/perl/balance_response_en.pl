
sub proc {
	my $f59;
	my $f74;
	my $f6;
	my $f22;
	my $f32;
	my $f33;
	my $f61;
	my $f69;
	my $f57;
	  ($f6,$f22,$f32,$f33,$f57,$f59,$f61,$f69,$f74) = @_;
	 
	  my $nextStateNum = "000";
	  my $nextScreenNum = "000";
	  my $nextScreenNumExt = "000";
	  my $cardflag= "0";
	  my $journaldata;	
	  my $receiptdata_now;
	  my $priceipt;
	  my $temp;
	  print "the value f39 is $f59 \n";
	  print "the value f54 is $f74 \n";
	  
	  if ($f59 eq "00") {
		$nextStateNum = "515";
		$nextScreenNum = "557";
		$cardflag= "0";
		#my $ledger =substr($f74,9,12);
	  	#my $avviable = substr($f74,29,12);
		my $ledger =  unpack('I',pack('I',substr($f74,8,12)));
	  	my $avviable = unpack('I',pack 'I',substr($f74,28,12));	
		print "ledger: $ledger\n";
	  	print "avviable: $avviable\n";
	  	$nextScreenNumExt = sprintf("507GI%d CNYDI%d CNY", $avviable,$ledger);
	} 	     
	  else
	  {
		$nextStateNum = "055";
	  }	 	  
	  if($f59 ne "00")
	  {
	  	$journaldata = sprintf("%s\n#ATM:%s\nDate:%s  Time:%s\nPan:%s\nTraceNo:%s  TransType:%s\n\
ErrorCode:%s\nSearchIndex:%s\n", "Banlance", $f61, $f33, $f32, $f22, $f31, "Banlance",$f59,$f57);
	  }	  
 
	  return ($nextStateNum, $nextScreenNum, $nextScreenNumExt, $journaldata, $receiptdata_now, $cardflag);
	}