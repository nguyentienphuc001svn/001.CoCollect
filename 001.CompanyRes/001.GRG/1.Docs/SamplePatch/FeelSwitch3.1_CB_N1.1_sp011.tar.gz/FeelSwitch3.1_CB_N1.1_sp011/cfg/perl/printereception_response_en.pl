
sub proc {
	my $f59;
	my $f74;
	my $f6;
	my $f22;
	my $f32;
	my $f33;
	my $f61;
	my $f69;
	my $f57;
	  ($f6,$f22,$f32,$f33,$f57,$f59,$f61,$f69,$f74) = @_;
	 
	  my $nextStateNum = "000";
	  my $nextScreenNum = "000";
	  my $nextScreenNumExt = "000";
	  my $cardflag= "0";
	  my $journaldata;	
	  my $receiptdata_now;
	  my $priceipt;
	  my $CardNumber = substr($f22,0,6)."******".substr($f22,12,4);
    	  #my $ledger = sprintf("%s",substr($f74,9,12));
	  #my $avviable = sprintf("%s",unpack('I',pack 'I',substr($f74,28,12)));
	  my $ledger = sprintf("%s",unpack('I',pack('I',substr($f74,8,12))));
	  my $avviable = sprintf("%s",unpack('I',pack 'I',substr($f74,28,12)));

	  
	  
	  print "the value f39 is $f59 \n";
	  print "the value f54 is $f74 \n";
	  print "ledger is $ledger\n";
	  print "available is $avviable\n";
	  print "the serials number is $f6 \n";
	  
	  if ($f59 eq "00") 
	  {
	  $nextStateNum = "557";
		$nextScreenNum = "552";
		
		
		 $journaldata = sprintf("%s\n#ATM:%s\nDate:%s  Time:%s\nPan:%s\nTraceNo:%s  TransType:%s\n\
RespCode:00\nSearchIndex:%s\n", "Banlance", $f61, $f33, $f32, $f22, $f6, "Banlance",$f57);
	  
	  open(my $FILEP, "../cfg/ndccfg/cent_data/prtformat/EN/101.txt") || die "open file error, $! ";
		while(defined($priceipt = <$FILEP>))
		{
			$receiptdata_now .= $priceipt;
		}
		close($FILEP);
		$receiptdata_now=~ s/#1/$f33/;	
		$receiptdata_now=~ s/#2/$f32/;	
		$receiptdata_now=~ s/#3/$f61/;	
		$receiptdata_now=~ s/#4/$CardNumber/;	
		$receiptdata_now=~ s/#9/$f6/;	
		$receiptdata_now=~ s/#5/$ledger/;	
		$receiptdata_now=~ s/#6/$avviable/;			
	  } 
	  else
	  {
		$nextStateNum = "055";
	  }	 	  
	  if($f59 ne "00")
	  {
	  	$journaldata = sprintf("%s\n#ATM:%s\nDate:%s  Time:%s\nPan:%s\nTraceNo:%s  TransType:%s\n\
ErrorCode:%s\nSearchIndex:%s\n", "Banlance", $f61, $f33, $f32, $f22, $f31, "Banlance",$f59,$f57);
	  }	  
	  
	  return ($nextStateNum, $nextScreenNum, $nextScreenNumExt,$journaldata, $receiptdata_now,$cardflag);
	}