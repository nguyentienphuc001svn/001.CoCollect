
FeelSwitch3.1_CB_N1.1_sp011
Date create(yyyy-mm-dd): 2013-12-06
Issue: upgrading CB current FeelSwitch can do transactions based on NDC+:
	- Balance Inquiry
	- Cash Withdrawal
	- Change Pin

Prerequisites: 
- FeelSwitch_CB_N1.1.1_sp010.tar

Installation Instructions:
Please run the "update_hot-fix.sh" script on FeelSwitch system.

Root cause: N/A
	
Solution:
   Configure NDC module.

Manual Modification:
	 1. Modify ../bin/fstart2: ./startndc
	 2. Modify ../bin/fstop2: ./stopndc
	
Script Modification(update_hot-fix.sh):
	1. Backup file ../cfg/ndccfg/cent_data: ndc_state.xml.
	2. Backup folder ../cfg/ndccfg/term_data: scrdata, statedata, para.
	3. Backup file ../cfg/perl: balance_request_en.pl, balance_response_en.pl, printereception_response_en.pl, withdraw_request_en.pl, withdraw_response_en.pl.
	4. copy folder cfg to ../cfg

Testing:
  - balance inquiry, cash withdraw, change pin

Testing expect:
  - return 00 for all messages