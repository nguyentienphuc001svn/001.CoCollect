
echo "stopping system..."
$FEEL_HOME/bin/fstop

sleep 5
CDATE=`date +%Y%m%d`
TODAY=`date +%Y%m%d%H%M`
CTIME=`date +%H%M`
echo "Backup Online Server"
mv  $FEEL_HOME/cfg/ndccfg/cent_data/ndc_state.xml $FEEL_HOME/cfg/ndccfg/cent_data/ndc_state.xml_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/ndccfg/term_data/scrdata $FEEL_HOME/cfg/ndccfg/term_data/scrdata_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/ndccfg/term_data/statedata $FEEL_HOME/cfg/ndccfg/term_data/statedata_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/ndccfg/term_data/para $FEEL_HOME/cfg/ndccfg/term_data/para_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/perl/balance_request_en.pl $FEEL_HOME/cfg/perl/balance_request_en.pl_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/perl/balance_response_en.pl $FEEL_HOME/cfg/perl/balance_response_en.pl_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/perl/printereception_response_en.pl $FEEL_HOME/cfg/perl/printereception_response_en.pl_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/perl/withdraw_request_en.pl $FEEL_HOME/cfg/perl/withdraw_request_en.pl_N1.1_sp011_$TODAY
mv  $FEEL_HOME/cfg/perl/withdraw_response_en.pl $FEEL_HOME/cfg/perl/withdraw_response_en.pl_N1.1_sp011_$TODAY

echo "Updating Online Server"
cp -rf cfg/ndccfg/* $FEEL_HOME/cfg/ndccfg/
cp -rf cfg/perl/* $FEEL_HOME/cfg/perl/

echo "Update Finish"
touch $FEEL_HOME/fwversion
echo $TODAY"_FEELSwitch3.1_CB_N1.1_sp011" >> $FEEL_HOME/fwversion